﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CL_Chat
{
    public enum Race: int
    {
        ABYSSIN = 1,
        EUROPEEN = 2,
        MAINE_COON = 3,
        SPHYNX = 4
    }
}
