class Pays {

    constructor(_nomPays) {

        this.nom = _nomPays;
        this.coche = false;

    }

}

export { Pays };